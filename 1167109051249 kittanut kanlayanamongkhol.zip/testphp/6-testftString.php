<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Funtion  with parameters</title>
</head>
<body>
    <h2>Writing PHP Funtion  which funtion calls</h2>
    <?php
    function sayHello() {
        echo "Hello Com Sci <br />";
    }
    $funtion_holder = "sayHello";
    $funtion_holder();
    sayHello();
    ?>
    
</body>
</html>