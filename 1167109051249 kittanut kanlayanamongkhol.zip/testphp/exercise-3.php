<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Funtion  with parameters</title>
</head>
<body>
<h2>Exercise-3</h2>
    <?php
    function test($x, $y) {

    return ($x <=20 || $y >= 50 ) || ($y <= 20 || $x >=50);

    }
    echo "<pre>";
    var_dump(test(20, 84));
    var_dump(test(14, 50));
    var_dump(test(11, 45));
    var_dump(test(25, 40));
    echo "</pre>";
    ?>
    
</body>
</html>