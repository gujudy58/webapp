<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Funtion</title>
</head>
<body>
    <h2>This is first time for PHP</h2>
    <?php
    /* Defining a PHP Funtion */
    function writeMessage(): void{
        echo "You are really a nice person, have a nice time";
    }
    /* Callling a PHP Funtion */
    writeMessage();
    ?>
</body>
</html>