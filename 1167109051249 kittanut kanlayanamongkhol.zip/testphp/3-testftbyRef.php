<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Funtion  with parameters</title>
</head>
<body>
    <h2>PHP with two parameters</h2>
    <?php
        function addFive(&$num) :void {
            $num += 5;
        }
 
        function addSix(&$num) :void {
            $num += 6;
        }
 
        $orignum = 10;
        addFive( $origum );
 
        echo "Original Value is $orignum<br />";
 
        addSix( $orignum);
        echo "Original Value is $orignum<br />";
 
    ?>
 </body>
 </html>