<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Funtion  with parameters</title>
</head>
<body>
<h2>Exercise-1</h2>
    <?php
    function test($str) {
        $s = substr($str, -1);
 
        return $s.$str.$s;
    }
    echo test("Red"). "\n <br />";
    echo test("Green"). "\n <br />";
    echo test("1"). "\n <br />";
    ?>
    
</body>
</html>