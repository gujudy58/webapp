<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Funtion  with parameters</title>
</head>
<body>
    <h2>PHP with two parameters</h2>
    <?php
    function printMe($param = Null) {
        print $param;
    }
    printMe("This is Test");
    printMe();
    printMe("<br />This is Test");
    printMe();printMe();
    ?>
</body>
</html>