<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Funtion  with parameters</title>
</head>
<body>
<h2>Exercise-2</h2>
    <?php
    function test($temp1, $temp2) {
        return $temp1 < 0 && $temp2 > 100|| $temp2 < 0 && $temp1 > 100;

    }
    echo "<pre>";
    var_dump(test(120, -1));
    var_dump(test(-1, 120));
    var_dump(test(2, 120));
    echo "</pre>";
    ?>
    
</body>
</html>