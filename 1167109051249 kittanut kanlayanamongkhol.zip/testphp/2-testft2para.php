<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Funtion  with parameters</title>
</head>
<body>
    <h2>PHP with two parameters</h2>
    <?php
    /* Defining a PHP Funtion */
    function addFuntion($sum1, $sum2): void{
        $sum = $sum1 + $sum2;
        echo "sum of the two numbers is : $sum";
    }
    /* Callling a PHP Funtion */
    addFuntion(10, 20);
    ?>
</body>
</html>