<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>แก้ไขข้อมูลสมาชิก</title>
    <link rel="stylesheet" href="editm.css">
</head>
<body>
<?php
        if(!isset($_GET['member_id'])){
            header("refresh: 0; url=mainmenu.php");
        }
        require 'conn.php';
        $sql = "SELECT * FROM members WHERE member_id='$_GET[member_id]'";
        $result = $conn->query($sql);
        $row = mysqli_fetch_array($result);
    ?>
    <form method="post" action="editmembersuccess.php">
        <p>

            <label>ชื่อ</label>
            <input type="text" name="member_id" id="member_id" value="<?=$row['member_id'];?>" hidden>
            <input type="text" name="name" id="name" value="<?=$row['name'];?>" />

        </p>

        <p>

            <label>นามสกุล</label>

            <input type="text" name="lastname" id="lastname" value="<?=$row['lastname'];?>" />

        </p>

        <p>

            <label>ที่อยู่</label>

            <input type="text" name="address" id="address" value="<?=$row['address'];?>" />

        </p>

        <p>

            <label>เบอร์โทร</label>

            <input type="text" name="telephone" id="telephone" value="<?=$row['telephone'];?>" />

        </p>
        <input type="submit" value="บันทึก">
        <a href='mainmenu.php'><button> Home</button></a>
    </form>

</body>
</html>
