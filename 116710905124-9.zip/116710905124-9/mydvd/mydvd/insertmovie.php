<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เพิ่มภาพยนตร์</title>

    <link rel="stylesheet" href="stylemovie.css">
</head>

<body>

<?php

require 'conn.php';

if (isset($_POST['save'])) {

    $title = $_POST['title'];
    $genre = $_POST['genre'];
    $price = $_POST['price'];
    $release_year = $_POST['release_year'];
    $stock = $_POST['stock'];

    $sql = "INSERT INTO movie
            (title, genre, price, release_year, stock)
            VALUES
            ('$title', '$genre', '$price', '$release_year', '$stock')";

    if ($conn->query($sql)) {

        echo "<script>
                alert('เพิ่มภาพยนตร์เรียบร้อยแล้ว');
                window.location='moviemenu.php';
              </script>";

    } else {

        echo "Error : " . $conn->error;
    }
}

?>

<div class="form-container">

    <div class="form-header">

        <div class="icon">+</div>

        <h2>เพิ่มภาพยนตร์</h2>

        <p>กรอกข้อมูลภาพยนตร์สำหรับร้านขายดีวีดี</p>

    </div>


    <div class="form-body">

        <form method="post">

            <label>
                ชื่อภาพยนตร์ <span>*</span>
            </label>

            <input
                type="text"
                name="title"
                placeholder="กรอกชื่อภาพยนตร์"
                required
            >


            <label>
                ประเภทภาพยนตร์ <span>*</span>
            </label>

            <input
                type="text"
                name="genre"
                placeholder="เช่น Action, Comedy, Horror"
                required
            >


            <label>
                ราคา <span>*</span>
            </label>

            <input
                type="number"
                name="price"
                placeholder="กรอกราคา"
                min="0"
                step="0.01"
                required
            >


            <label>
                ปีที่ฉาย <span>*</span>
            </label>

            <input
                type="number"
                name="release_year"
                placeholder="เช่น 2025"
                min="1900"
                max="2100"
                required
            >


            <label>
                จำนวนสินค้า <span>*</span>
            </label>

            <input
                type="number"
                name="stock"
                placeholder="กรอกจำนวน DVD"
                min="0"
                required
            >


            <div class="form-buttons">

                <button
                    type="submit"
                    name="save"
                    class="btn-save">
                    บันทึกข้อมูล
                </button>


                <a href="moviemenu.php">

                    <button
                        type="button"
                        class="btn-back">
                        กลับหน้าหลัก
                    </button>

                </a>

            </div>

        </form>

    </div>

</div>

</body>
</html>