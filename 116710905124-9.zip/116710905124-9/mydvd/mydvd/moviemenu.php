<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ข้อมูลภาพยนตร์</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<?php
require 'conn.php';

$sql = "SELECT * FROM movie";
$result = $conn->query($sql);

if (!$result) {
    die("Error : " . $conn->error);
}
?>

<div class="container">

    <h1>ข้อมูลภาพยนตร์</h1>

    <div class="top-buttons">
        <a href="insertmovie.php">
            <button class="btn-add">+ เพิ่มภาพยนตร์ใหม่</button>
        </a>

        <a href="index.php">
            <button class="btn-home">หน้าแรก</button>
        </a>
    </div>

    <div class="table-box">

        <table>

            <thead>
                <tr>
                    <th>ID</th>
                    <th>ชื่อภาพยนตร์</th>
                    <th>ประเภท</th>
                    <th>ราคา</th>
                    <th>ปีที่ฉาย</th>
                    <th>จำนวนสินค้า</th>
                    <th>Edit</th>
                </tr>
            </thead>

            <tbody>

            <?php

            if ($result->num_rows > 0) {

                while ($row = $result->fetch_assoc()) {

                    echo "<tr>";

                    echo "<td>" . $row["movie_id"] . "</td>";

                    echo "<td>" . $row["title"] . "</td>";

                    echo "<td>" . $row["genre"] . "</td>";

                    echo "<td>" . $row["price"] . "</td>";

                    echo "<td>" . $row["release_year"] . "</td>";

                    echo "<td>" . $row["stock"] . "</td>";

                    echo "<td>
                            <a href='editmovie.php?movie_id=".$row["movie_id"]."'>
                                <button class='btn-edit'>✎ แก้ไข</button>
                            </a>
                          </td>";

                    echo "</tr>";
                }

            } else {

                echo "<tr>
                        <td colspan='7'>ไม่พบข้อมูลภาพยนตร์</td>
                      </tr>";
            }

            $conn->close();

            ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>