<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>แก้ไขข้อมูลภาพยนตร์</title>

    <link rel="stylesheet" href="stylemovie.css">
</head>

<body>

<?php

require 'conn.php';

/* รับ movie_id จากหน้ารายการ */
$movie_id = $_GET['movie_id'];

/* ดึงข้อมูลภาพยนตร์ */
$sql = "SELECT * FROM movie WHERE movie_id = $movie_id";

$result = $conn->query($sql);

if (!$result) {
    die("Error : " . $conn->error);
}

$row = $result->fetch_assoc();

?>


<div class="form-container">

    <div class="form-header">

        <div class="icon">✎</div>

        <h2>แก้ไขข้อมูล</h2>

        <p>แก้ไขรายละเอียดข้อมูลภาพยนตร์</p>

    </div>


    <div class="form-body">

        <form method="post">

            <!-- ชื่อภาพยนตร์ -->

            <label>
                ชื่อภาพยนตร์ <span>*</span>
            </label>

            <input
                type="text"
                name="title"
                value="<?php echo $row['title']; ?>"
                required
            >


            <!-- ประเภท -->

            <label>
                ประเภทภาพยนตร์ <span>*</span>
            </label>

            <input
                type="text"
                name="genre"
                value="<?php echo $row['genre']; ?>"
                required
            >


            <!-- ราคา -->

            <label>
                ราคา <span>*</span>
            </label>

            <input
                type="number"
                name="price"
                value="<?php echo $row['price']; ?>"
                min="0"
                step="0.01"
                required
            >


            <!-- ปีที่ฉาย -->

            <label>
                ปีที่ฉาย <span>*</span>
            </label>

            <input
                type="number"
                name="release_year"
                value="<?php echo $row['release_year']; ?>"
                min="1900"
                max="2100"
                required
            >


            <!-- จำนวนสินค้า -->

            <label>
                จำนวนสินค้า <span>*</span>
            </label>

            <input
                type="number"
                name="stock"
                value="<?php echo $row['stock']; ?>"
                min="0"
                required
            >


            <!-- ปุ่ม -->

            <div class="form-buttons">

                <button
                    type="submit"
                    name="update"
                    class="btn-save">
                    บันทึกการแก้ไข
                </button>


                <a href="moviemenu.php">

                    <button
                        type="button"
                        class="btn-back">
                        กลับหน้าหลัก
                    </button>

                </a>

            </div>

        </form>


<?php

/* เมื่อกดบันทึก */

if (isset($_POST['update'])) {

    $title = $_POST['title'];
    $genre = $_POST['genre'];
    $price = $_POST['price'];
    $release_year = $_POST['release_year'];
    $stock = $_POST['stock'];


    $sql = "UPDATE movie SET

            title = '$title',
            genre = '$genre',
            price = '$price',
            release_year = '$release_year',
            stock = '$stock'

            WHERE movie_id = $movie_id";


    if ($conn->query($sql)) {

        echo "<script>

                alert('แก้ไขข้อมูลภาพยนตร์เรียบร้อยแล้ว');

                window.location='moviemenu.php';

              </script>";

    } else {

        echo "Error : " . $conn->error;
    }

}

?>

    </div>

</div>


</body>
</html>