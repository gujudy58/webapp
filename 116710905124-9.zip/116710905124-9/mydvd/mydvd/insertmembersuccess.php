<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
require 'conn.php';
    $sql_update="INSERT INTO members(member_id,name,lastname,address,telephone) VALUES ('$_POST[member_id]','$_POST[name]','$_POST[lastname]' ,'$_POST[address]' ,'$_POST[telephone]')";

    $result= $conn->query($sql_update);

    if(!$result) {
        die("Error God Damn it : ". $conn->error);
    } else {

    echo "Insert Success <br>";
    header("refresh: 1; url=mainmenu.php");
    }
?>
</body>
</html>