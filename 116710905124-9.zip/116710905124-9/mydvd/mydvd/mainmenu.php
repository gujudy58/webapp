<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Information</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<?php
    require 'conn.php';

    $sql = "SELECT * FROM members";
    $result = $conn->query($sql);

    if (!$result) {
        die("Error : " . $conn->error);
    }
?>

<div class="container">

    <h1>สมาชิก</h1>

    <div class="top-buttons">

        <a href="insertmember.php">
            <button class="btn-add">+ เพิ่มสมาชิกใหม่</button>
        </a>

        <a href="index.php">
            <button class="btn-home">หน้าแรก</button>
        </a>

    </div>

    <div class="table-box">

        <table>

            <thead>
                <tr>
                    <th>ID</th>
                    <th>ชื่อ-นามสกุล</th>
                    <th>ที่อยู่</th>
                    <th>เบอร์โทร</th>
                    <th>Edit</th>
                </tr>
            </thead>

            <tbody>

            <?php

                if ($result->num_rows > 0) {

                    while ($row = $result->fetch_assoc()) {

                        echo "<tr>";

                        // ID
                        echo "<td>" . $row["member_id"] . "</td>";

                        // ชื่อ + นามสกุล
                        echo "<td>" . $row["name"] . " " . $row["lastname"] . "</td>";

                        // ที่อยู่
                        echo "<td>" . $row["address"] . "</td>";

                        // เบอร์โทร
                        echo "<td>" . $row["telephone"] . "</td>";

                        // ปุ่มแก้ไข
                        echo "<td>
                                <a href='editmember.php?member_id=" . $row["member_id"] . "'>
                                    <button class='btn-edit'>✎ แก้ไข</button>
                                </a>
                              </td>";

                        echo "</tr>";
                    }

                } else {

                    echo "<tr>
                            <td colspan='5'>ไม่พบข้อมูลสมาชิก</td>
                          </tr>";
                }

                $conn->close();

            ?>

            </tbody>

        </table>

    </div>

</div>

</body>
</html>