<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method="post" action="insertmembersuccess.php">
        <p>

            <label>รหัสสมาชิก</label>
            <input type="text" name="member_id" id="member_i">
        </p>
        <p>

            <label>ชื่อ</label>
            <input type="text" name="name" id="name">

        </p>

        <p>

            <label>นามสกุล</label>

            <input type="text" name="lastname" id="lastname">

        </p>

        <p>

            <label>ที่อยู่</label>

            <input type="text" name="address" id="address">

        </p>

        <p>

            <label>เบอร์โทร</label>

            <input type="text" name="telephone" id="telephone">

        </p>
        <input type="submit" value="บันทึก">
        <a href='mainmenu.php'> <button> Home </button></a>
    </form>

    
</body>
</html>