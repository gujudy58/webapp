console.log("Hello Javascript");
console.log("Hello Computer Scienct");
document.getElementById("text").interHML = "This is first time for JavaScript"
document.write("Hello document write");
Window.alert("welcome to my page");